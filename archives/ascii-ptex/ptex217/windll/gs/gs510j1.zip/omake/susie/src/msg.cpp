#include "gs.h"

int Message(UINT uId, UINT uFlag)
{
  char buf[512];
  ::LoadString(g_hModule, uId, buf, 512);
  return ::MessageBox(0, buf, 0, uFlag);
}
