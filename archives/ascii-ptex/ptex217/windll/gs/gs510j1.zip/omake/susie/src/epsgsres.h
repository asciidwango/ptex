//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by epsgs.rc
//
#define IDD_SETUP                       101
#define IDI_PS                          103
#define IDS_ANTIALIAS_1                 1000
#define IDS_ANTIALIAS_2                 1001
#define IDS_ANTIALIAS_4                 1002
#define IDC_BROWSE_GS                   1007
#define IDC_GS                          1008
#define IDS_BPP_DEFAULT                 1010
#define IDC_ALPHA_TEXT                  1011
#define IDS_BPP_1                       1011
#define IDC_ALPHA_GRAPHICS              1012
#define IDS_BPP_4                       1012
#define IDC_CLIP                        1013
#define IDS_BPP_8                       1013
#define IDS_BPP_24                      1014
#define IDC_XDPI_SPIN                   1015
#define IDC_YDPI_SPIN                   1016
#define IDC_NORMAL_ASPECT               1017
#define IDC_XDPI                        1018
#define IDC_YDPI                        1019
#define IDC_COLOR                       1020
#define IDS_MAGIC_PERCENT               1020
#define IDC_YDPI_LABEL                  1021
#define IDS_MAGIC_PS                    1021
#define IDC_YDPI_DPI                    1022
#define IDS_MAGIC_ADOBE                 1022
#define IDC_RESTART_ALWAYS              1023
#define IDS_MAGIC_EPSF                  1023
#define IDC_MAGIC_NUMBER                1024
#define IDC_PAPER                       1026
#define IDS_ERROR_SETGSPATH             2000
#define IDS_ERROR_LOADGS                2001
#define IDS_ERROR_GSENTRYPOINT          2002
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
