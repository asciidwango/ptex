//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wdvips.rc
//
#define IDD_PROGRESS                    101
#define IDI_WDVIPS                      102
#define IDD_MESSAGE                     103
#define IDD_PRINT                       105
#define IDD_DETAIL                      106
#define IDC_FILENAME                    1000
#define IDC_MESSAGE                     1001
#define IDC_PAGE                        1002
#define IDC_CTRL_D                      1004
#define IDC_HYPER                       1005
#define IDC_ODD_PAGE                    1006
#define IDC_EVEN_PAGE                   1007
#define IDC_ALL_PAGE                    1008
#define IDC_CONFIG                      1013
#define std32                           0x045f
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
