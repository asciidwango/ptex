#include <windows.h>
#include <win32dll/texdll.h>

#ifdef TeX
#  define TeXDLL     "tex.dll"
#  define TeXName    "TeX"
#endif
#ifdef PTeX
#  define TeXDLL     "ptex.dll"
#  define TeXName    "PTeX"
#endif
#ifdef MF
#  define TeXDLL     "mf.dll"
#  define TeXName    "MF"
#endif
#ifdef MP
#  define TeXDLL     "mpost.dll"
#  define TeXName    "MP"
#endif
#ifdef MFtoPK
#  define TeXDLL     "mftopk.dll"
#  define TeXName    "MFtoPK"
#endif
#ifdef BibTeX
#  define TeXDLL     "bibtex.dll"
#  define TeXName    "BibTeX"
#endif
#ifdef JBibTeX
#  define TeXDLL     "jbibtex.dll"
#  define TeXName    "JBibTeX"
#endif
#ifdef PatGen
#  define TeXDLL     "patgen.dll"
#  define TeXName    "PatGen"
#endif
#ifdef GFtoDVI
#  define TeXDLL     "gftodvi.dll"
#  define TeXName    "GFtoDVI"
#endif
#ifdef GFtoPK
#  define TeXDLL     "gftopk.dll"
#  define TeXName    "GFtoPK"
#endif
#ifdef GFType
#  define TeXDLL     "gftype.dll"
#  define TeXName    "GFType"
#endif
#ifdef PKtoGF
#  define TeXDLL     "pktogf.dll"
#  define TeXName    "PKtoGF"
#endif
#ifdef PKType
#  define TeXDLL     "pktype.dll"
#  define TeXName    "PKType"
#endif
#ifdef PLtoTF
#  define TeXDLL     "pltotf.dll"
#  define TeXName    "PLtoTF"
#endif
#ifdef TFtoPL
#  define TeXDLL     "tftopl.dll"
#  define TeXName    "TFtoPL"
#endif
#ifdef VFtoVP
#  define TeXDLL     "vftovp.dll"
#  define TeXName    "VFtoVP"
#endif
#ifdef VPtoVF
#  define TeXDLL     "vptovf.dll"
#  define TeXName    "VPtoVF"
#endif
#ifdef MFT
#  define TeXDLL     "mft.dll"
#  define TeXName    "MFT"
#endif
#ifdef DVICopy
#  define TeXDLL     "dvicopy.dll"
#  define TeXName    "DVICopy"
#endif
#ifdef DVItoMP
#  define TeXDLL     "dvitomp.dll"
#  define TeXName    "DVItoMP"
#endif
#ifdef DVIType
#  define TeXDLL     "dvitype.dll"
#  define TeXName    "DVIType"
#endif
#ifdef PDVIType
#  define TeXDLL     "pdvitype.dll"
#  define TeXName    "PDVIType"
#endif
#ifdef Tangle
#  define TeXDLL     "tangle.dll"
#  define TeXName    "Tangle"
#endif
#ifdef Weave
#  define TeXDLL     "weave.dll"
#  define TeXName    "Weave"
#endif
#ifdef PoolType
#  define TeXDLL     "pooltype.dll"
#  define TeXName    "PoolType"
#endif
#ifdef Mendex
#  define TeXDLL     "mendex.dll"
#  define TeXName    "Mendex"
#endif

#define GetProcedures TeXName "GetProcedures"

extern LONG WINAPI
CUITeXMain(LPCTSTR DLLName, LPCTSTR GetProcName, LONG argc, LPTSTR* argv);

/* Main function.
   Just calls *Main() functions (e.g. TeXMain) in the DLL's.
 */
int main(int argc, char** argv)
{
  return CUITeXMain(TeXDLL, GetProcedures, argc, argv);
}
