//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by custres.rc
//
#define IDD_CUI_PAGE                    101
#define IDD_GENERAL_PAGE                102
#define IDD_MAKETEX_PAGE                103
#define IDD_EDIT_MODE                   104
#define IDI_TEXCUST                     105
#define IDD_DIALOG1                     105
#define IDC_EDITOR                      1000
#define IDC_BROWSE_EDITOR               1001
#define IDC_METAFONT_DISPLAY_VALID      1002
#define IDC_CHANGE_FOREGROUND           1003
#define IDC_CHANGE_BACKGROUND           1004
#define IDC_TARGET_USER                 1005
#define IDC_TARGET_SYSTEM               1006
#define IDC_RESET_USER                  1007
#define IDC_MODES                       1008
#define IDC_REMOVE                      1009
#define IDC_ADD                         1010
#define IDC_DPI                         1013
#define IDC_KEEP_DIRECTORY_STRUCTURE    1014
#define IDC_MODE                        1015
#define IDC_UPDATE_LSR                  1015
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
