struct MakeTeXCallbackInfo_s;
typedef struct MakeTeXCallbackInfo_s MakeTeXCallbackInfo;

extern HANDLE hMakeTeXModule;
extern CRITICAL_SECTION critical_section;

extern LONG WINAPI MakeTeXCallback(TeXDLLMessage msg,
				   DWORD param1, DWORD param2,
				   LPVOID app_data);
extern MakeTeXCallbackInfo* MakeTeXInitCallback(BOOL verbose_f);
extern VOID MakeTeXUninitCallback(MakeTeXCallbackInfo* pinfo);

extern LPSTR GetMode(UINT dpi);
extern LPSTR GetPKDirectory(LPCSTR name, LPCSTR mode);
extern LPSTR GetTFMDirectory(LPCSTR name);
