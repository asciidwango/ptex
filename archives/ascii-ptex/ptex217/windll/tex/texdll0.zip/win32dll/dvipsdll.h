#ifndef dvipsdll_h_included
#define dvipsdll_h_included

#define kpse_open_file    dvipsdll_open_file
#define kpse_set_progname dvipsdll_set_progname
#define kpse_set_program_enabled dvipsdll_set_program_enabled
#define kpse_init_prog    dvipsdll_init_prog
#define kpse_find_file   dvipsdll_find_file
#define kpse_var_value    dvipsdll_var_value

#define kpse_find_glyph   dvipsdll_find_glyph
#define kpse_tex_hush     dvipsdll_tex_hush
#define kpse_magstep_fix  dvipsdll_magstep_fix
#define kpse_bitmap_tolerance dvipsdll_bitmap_tolerance

#define kpse_absolute_p  dvipsdll_absolute_p
#define kpse_fopen_trace dvipsdll_fopen
#define kpse_fclose_trace dvipsdll_fclose

#define concat3           dvipsdll_concat3
#define xfopen            dvipsdll_fopen
#define xfclose(f,n)      dvipsdll_fclose(f)

#endif
