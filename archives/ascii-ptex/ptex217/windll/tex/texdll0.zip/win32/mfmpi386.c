/* i386 assembly routines for inner loop fraction routines in Metafont
   and MetaPost. Included from texmfmp.c. By Wayne Sullivan
   <wgs@maths.ucd.ie>.  */

int ztakefraction(int p, int q) {
__asm {
        push ebp
	mov esp,ebp
        xor ecx,ecx
        mov [ebp+8],eax
        cmp $0x80000000,eax
        jz LL5
        imul [ebp+12]
        or edx,edx
        jns LL2
        neg edx
        neg eax
        sbb ecx,edx
        inc ecx
LL2:
        add $0x08000000,eax
        adc $0,edx
        cmp $0x07ffffff,edx
        ja LL3
        shrd edx,eax,28
LL1:
	jecxz LL4
        neg eax
LL4:
        mov ebp,esp
        pop ebp
        ret
LL5:     
	inc ecx
LL3:     
	mov $0x7fffffff,eax
        mov $1,_aritherror
        jmp LL1
}
}

int ztakescaled(int p, int q) {
__asm {
        push ebp
	mov esp,ebp
        mov [ebp+8],eax
        xor ecx,ecx
        cmp $0x80000000,eax
        jz LL5
        imul [ebp+12]
        or edx,edx
        jns LL12
        neg edx
        neg eax
        sbb ecx,edx
        inc ecx
LL12:
        add $0x00008000,eax
        adc $0,edx
        cmp $0x00007fff,edx
        ja LL3
        shrd edx,eax,16
        jecxz LL4
        neg eax
        jmp LL4
	  }
}

int zmakescaled(int p, int q) {
  __asm {
        mov $16,cl
        mov $0,ch
        push ebp
	mov esp,ebp
        push ebx
        mov [ebp+8],edx
        xor eax,eax
        or edx,edx
        jns LL32
        inc ch
        neg edx
LL32:
        mov [ebp+12],ebx
        or ebx,ebx
        jns LL33
        dec ch
        neg ebx
        or ebx,ebx
        js LL34
LL33:
        or edx,edx
        js LL34
        shrd edx,eax,cl
        shl edx,cl
        cmp ebx,edx
        jae LL34
        div ebx
        add edx,edx
        inc edx
        sub edx,ebx
        adc $0,eax
        jc LL34
        cmp $0x7fffffff,eax
        ja LL34
LL31:    or ch,ch
        jz LL35
        neg eax
LL35:
        pop ebx
        mov ebp,esp
        pop ebp
        ret
LL34:    
        mov $0x7fffffff,eax
	mov $1,_aritherror
        jmp LL31

  }
}
int zmakefraction(int p, int q) {
  __asm {
        mov $4,cl
        mov $0,ch
        push ebp
	mov esp,ebp
        push ebx
        mov [ebp+8],edx
        xor eax,eax
        or edx,edx
        jns LL32
        inc ch
        neg edx
LL32:
        mov [ebp+12],ebx
        or ebx,ebx
        jns LL33
        dec ch
        neg ebx
        or ebx,ebx
        js LL34
LL33:
        or edx,edx
        js LL34
        shrd cl,edx,eax
        shl edx,cl
        cmp ebx,edx
        jae LL34
        div ebx
        add edx,edx
        inc edx
        sub edx,ebx
        adc $0,eax
        jc LL34
        cmp $0x7fffffff,eax
        ja LL34
LL31:    or ch,ch
        jz LL35
        neg eax
LL35:
        pop ebx
        mov ebp,esp
        pop ebp
        ret
LL34:    
        mov $0x7fffffff,eax
        mov $1,_aritherror
        jmp LL31

  }
}


