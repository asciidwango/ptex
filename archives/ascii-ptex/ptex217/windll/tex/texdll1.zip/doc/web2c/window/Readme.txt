This directory contains the support for Metafont's online graphics.
The various pieces are used and invoked from lib/texmfmp.c.
