These files are present for informational purposes.  They are not used
or installed by the programs.  All of them are available elsewhere, and
the versions in this distribution may be out of date.

COPYING and COPYING.LIB contain the GNU Public Licenses, which apply to
the binaries created by this distribution, and some of the source
files.  (Each source file states its copying conditions.)

MIRROR is a list of mirror sites for TeX and GNU software.  (For the
latest, finger ctan@ftp.tug.org and fsf@prep.ai.mit.edu, respectively.)

texinfo.tex is the macro file needed to produce DVI files to print the
documentation.  (For the latest, check the latest GNU distribution, or
/gd/gnu/texinfo/texinfo.tex if you have an account on the FSF machines.)

unixtex.ftp describes how to obtain a TeX system by ftp or on physical
media, and some alternative TeX distributions.  (See
http://www.tug.org/unixtex.ftp.)
