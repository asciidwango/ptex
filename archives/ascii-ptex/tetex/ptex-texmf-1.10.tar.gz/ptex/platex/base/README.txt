===========================================================================
                         pLaTeX2e <2000/11/03>

                  Copyright 1995-2000 ASCII Corporation
===========================================================================

---------------------------------------------------------------------------
$B!|(B pLaTeX2e $B$K$D$$$F(B
---------------------------------------------------------------------------
 * pLaTeX2e <2000/11/03> $BHG$O(B LaTeX2e <2000/06/01> $BHG$KBP1~$7$F$$$^$9!#(B

 * pLaTeX2e $B$O!"(B TeX $B%P!<%8%g%s(B 3.1415 $B0J9_$r%Y!<%9$K$7$?(B pTeX $B$GF0:n$r$7(B
   $B$^$9!#$=$l0J30$N(B TeX $B$G$OF0:n$7$^$;$s$N$G!"$4Cm0U$/$@$5$$!#(B

 * pLaTeX2e $B$O!"(BLaTeX2e $B$KF|K\8l$NAHHG5!G=$rDI2C$7$?$b$N$G$9!#(B
   LaTeX2e $B$O!"(BLaTeX$B$N?7$7$$%P!<%8%g%s$G$"$j!"(B $B=>Mh$N(B LaTeX$B%P!<%8%g%s(B2.09
   $B$H$OFbIt9=B$$,Bg$-$/0[$J$C$F$$$^$9!#(B $B$=$N$?$a!"%P!<%8%g%s(B2.09 $B$H$N8_49(B
   $B@-$O!V8_49%b!<%I!W$H$$$&7A$G<h$C$F$$$^$9!#(BpLaTeX2e$B$bF1MM$K!"%P!<%8%g%s(B
   2.09$B$r%Y!<%9$K$7$?!"(B jLaTeX $B$*$h$S(B pLaTeX $B$H$N8_49@-$O8_49%b!<%I$GBP=h(B
   $B$7$F$$$^$9!#5l%P!<%8%g%s$H$N8_49@-$K$D$$$F$N>\:Y$O!"(Bpl209.dtx $B%U%!%$%k(B
   $B$r;2>H$7$F$/$@$5$$!#(B

 * $B$3$N(B pLaTeX2e $B$O!"<!$N;v9`$r3NG'$N$&$(!"$4MxMQ$/$@$5$$!#(B

   1. $BK\%W%m%0%i%`$N!"F|K\8l2=ItJ,$K4X$7$F$O3t<02q<R%"%9%-!<$KCx:n8"$,(B
      $B$"$j$^$9!#(B

   2. $B$=$N;HMQ$,D>@\E*$J1DMxL\E*!JNc$($P!"MxMQ<T$+$i%W%m%0%i%`$N;HMQNA(B
      $B6b$r$H$kEy!K$G$J$$8B$j!"$I$N$h$&$JJ}K!!"L\E*$G;HMQ$5$l$F$b$+$^$$(B
      $B$^$;$s!#$?$@$7!"$=$l$K$h$j@8$8$?LdBj$K4X$7$F$O0l@Z!"3t<02q<R%"%9(B
      $B%-!<$G$O@UG$$r;}$A$^$;$s!#(B

   3. $BB><T$X$N%3%T!<$O!"$=$N9T0Y$,1DMxL\E*$G$J$$>l9g$K8B$j<+M3$K9T$J$C(B
      $B$F7k9=$G$9!#(B

   4. $BK\%W%m%0%i%`(B $B!JF|K\8l2=$K4X78$9$kItJ,!K(B $B$N2~JQ$K$D$$$F$O<+M3$K9T(B
      $B$J$C$F$+$^$$$^$;$s!#$?$@$7Bh#39`$K$D$$$F$O!"2~JQA0$N$b$N$^$?$O2~(B
      $BJQA0$N>uBV$K4JC1$KLa$;$k7A$G9T$J$C$F2<$5$$!#(B

      $B2~JQFbMF$K$D$$$F$O3t<02q<R%"%9%-!<$X$NDLCN5AL3$,$"$k$b$N$H$7!"$=(B
      $B$N8x3+$K$D$$$F$O;vA0$N>5Bz$rI,MW$H$7$^$9!#(B

   5. $BK\%W%m%0%i%`$N;HMQ$^$?$O!";HMQITG=$+$i@8$:$k$$$+$J$kB>$NB;32$K4X(B
      $B$7$F$b!"3t<02q<R%"%9%-!<$O!"0l@Z@UG$$rIi$o$J$$$b$N$H$7$^$9!#(B


---------------------------------------------------------------------------
$B!|(B $B%$%s%9%H!<%k(B
---------------------------------------------------------------------------
pLaTeX2e $B$r%$%s%9%H!<%k$9$k$K$O!"(BpTeX $B$H(B LaTeX2e $B$N%U%!%$%k$,I,MW$G$9!#(B
$B$3$N%I%-%e%a%s%H$G$O!"$9$G$K(B pTeX $B$,%$%s%9%H!<%k$5$l$F$$$k$b$N$H$7$F@b(B
$BL@$7$^$9!#(BpTeX $B$N%$%s%9%H!<%k$K$D$$$F$O!"(BpTeX $B$KIUB0$N%I%-%e%a%s%H$r;2(B
$B>H$7$F$/$@$5$$!#(B pTeX $B$N%=!<%9%U%!%$%k$O!"0J2<$N%5%$%H$J$I$+$iF~<j$9$k(B
$B$3$H$,$G$-$^$9!#(B

    * ftp://ftp.ascii.co.jp/pub/TeX/ascii-ptex
    * ftp://ftp.kuis.kyoto-u.ac.jp/TeX/ASCII-pTeX
    * ftp://bash.cc.keio.ac.jp/pub/TeX/ascii-ptex

LaTeX2e $B$O!"(BCTAN $B%5%$%H$N(B macros/latex/base $B%G%#%l%/%H%j$+$iF~<j$9$k$3(B
$B$H$,$G$-$^$9!#<g$J(B CTAN $B%5%$%H$O$D$.$N$H$*$j$G$9!#(B

    * ftp://ftp.u-aizu.ac.jp/pub/tex/CTAN
    * ftp://ftp.riken.go.jp/pub/tex-archive
    * ftp://lab.kdd.co.jp/TeX/CTAN
    * ftp://ftp.shsu.edu/tex-archive
    * ftp://ftp.dante.de/tex-archive
    * ftp://ftp.tex.ac.uk/tex-archive

LaTeX2e $B$G$O!"%G%U%)%k%H$G(B EC $B%(%s%3!<%I$N%U%)%s%H$,MQ$$$i$l$F$$$^$9!#(B
EC $B%(%s%3!<%I$N%U%)%s%H$O!"(BCTAN $B%5%$%H$N(B fonts/ec $B%G%#%l%/%H%j$K$"$j$^$9!#(B

$B%$%s%9%H!<%k$O!"$D$.$N=g=x$G?J$a$F$$$-$^$9!#(B

  1. LaTeX2e $B$N%$%s%9%H!<%k(B
  2. pLaTeX2e $B$N%$%s%9%H!<%k(B

LaTeX2e $B$N%$%s%9%H!<%k$K$D$$$F$N>\:Y$O(B LaTeX2e $B$KIUB0$N(B install.txt $B$r(B
$B;2>H$7$F$/$@$5$$!#(BLaTeX 2.09 $B$N%7%9%F%`$NJ]B8J}K!$J$I$b=R$Y$i$l$F$$$^$9!#(B
$B$3$NJ8=q$G$O!"%$%s%9%H!<%k<j=g$N35MW$@$1<($7$^$9!#(B

$B0JA0$N%P!<%8%g%s$N(B  LaTeX2e $B$d(B pLaTeX2e $B$r%$%s%9%H!<%k$7$F$"$k>l9g$O!"(B
$B0J8e$N:n6H$r?J$a$kA0$K!"!JI,MW$J$i$P%P%C%/%"%C%W$r<h$C$F$+$i!K$=$l$i$r(B
$B:o=|$7$F$/$@$5$$!#%G%U%)%k%H$N@_Dj$G%$%s%9%H!<%k$7$F$"$k>l9g!"(B LaTeX2e
$B$H(B pLaTeX2e $B$O!"$=$l$>$l!"$D$.$N%G%#%l%/%H%j$K$"$j$^$9!#$3$3$G!"(B$TEXMF
$B$O!"(BTeX $B$N%i%$%V%i%j%G%#%l%/%H%j!J$?$H$($P!"(B/usr/local/share/texmf$B!K$r(B
$B0UL#$7$^$9!#(B

    LaTeX2e  --- $TEXMF/tex/latex/base
    pLaTeX2e --- $TEXMF/tex/platex/base

----------------------------------------
1. LaTeX2e $B$N%$%s%9%H!<%k(B
----------------------------------------
(1) $TEXMF/fonts/public/ec $B%G%#%l%/%H%j$K(B EC $B%U%)%s%H$N%U%!%$%kCV$-$^$9!#(B
    DC $B%U%)%s%H$O:o=|$7$F$/$@$5$$!#(B

(2) $TEXMF/tex/latex/base $B%G%#%l%/%H%j$K(B LaTeX2e $B$N%U%!%$%k$rCV$-$^$9!#(B
    $B$3$3$G!"3F%U%!%$%k$K=q$-9~$_5v2D$,$"$k$+$I$&$+$r3NG'$7$F$/$@$5$$!#(B
    $B$J$$>l9g$O!"(Bchmod $B%3%^%s%I$J$I$G!"=q$-9~$_5v2D$rM?$($F$/$@$5$$!#(B

(3) unpack.ins $B$r=hM}$7$^$9!#(B

        tex -ini unpack.ins

(4) $B%U%)!<%^%C%H%U%!%$%k$r:n@.$7$^$9!#(B

        tex -ini latex.ltx

(5) $B%U%)!<%^%C%H%U%!%$%k$r0\F0$7$^$9!#(B

        mv -f latex.fmt $TEXMF/web2c

(6) $B<B9T%U%!%$%k$r:n@.$7$^$9(B

        cd /usr/local/bin
        ln -s tex latex

(7) $B@5$7$/%$%s%9%H!<%k$G$-$?$+$r3NG'$9$k$K$O!"<!$N%3%^%s%I$r<B9T$7$^$9!#(B

        cd /tmp
        latex ltxcheck

	$B<B9T7k2L$O(B ltxcheck.log $B$K5-O?$5$l$F$$$^$9!#@5$7$/%$%s%9%H!<%k$5$l(B
	$B$F$$$l$P!"$9$Y$F$N%F%9%H$,(B "OK" $B$K$J$j$^$9!#%(%i!<$,I=<($5$l$?>l9g(B
	$B$O!"$=$N;X<($K=>$C$F4D6-$r9=C[$7D>$7$^$9!#(B

----------------------------------------
2. pLaTeX2e $B$N%$%s%9%H!<%k(B
----------------------------------------
(1) $TEXMF $B%G%#%l%/%H%j$K(B ptex-texmf-*.tar.gz $B$rE83+$7$^$9!#(B

(2) $B%U%)!<%^%C%H%U%!%$%k$r:n@.$7$^$9!#(B

        ptex -ini platex.ltx

(3) $B%U%)!<%^%C%H%U%!%$%k$r0\F0$7$^$9!#(B

        mv -f platex.fmt $TEXMF/web2c

(4) $B<B9T%U%!%$%k$r:n@.$7$^$9!#(B

        cd /usr/local/bin
        ln -s ptex platex

(5) ls-R $B%U%!%$%k$r99?7$7$^$9!#(B

        mktexlsr

---------------------------------------------------------------------------
$B!|(B pLaTeX2e $B$NJ8=q%U%!%$%k$K$D$$$F(B
---------------------------------------------------------------------------
pLaTeX2e $B$N%Q%C%1!<%8$K4^$^$l$F$$$k%U%!%$%k$N$&$A!"3HD%;R$,(B .dtx $B$N%U%!%$(B
$B%k$O!"(BpLaTeX2e $B$GDj5A$r$7$F$$$k%3%^%s%I$N%=!<%9%3!<%I!"%=!<%9%3!<%I$N@bL@!"(B
$B%3%^%s%I$N4JC1$J;H$$J}$J$I$r$^$H$a$?J8=q%U%!%$%k$G$9!#(B.dtx $B%U%!%$%k$O!"D>(B
$B@\!"(BpLaTeX2e $B$G=hM}$G$-$^$9!#(B

    platex platex.dtx

$B$^$?!"(Bpldoc.tex $B%U%!%$%k$r=hM}$9$l$P!"$9$Y$F$N(B dtx $B%U%!%$%k$r$^$H$a$F!"0l(B
$B$D$NJ8=q%U%!%$%k$H$7$F:n@.$9$k$3$H$b$G$-$^$9!#(B

    platex pldoc.tex

pldoc.tex $B$+$i(B pldoc.dvi $B$r:n@.$9$k<j=g$O!"(Bplatex.dtx $B%U%!%$%k$G@bL@$r$7$F(B
$B$$$^$9!#(BUNIX $B4D6-$J$i$P!"$D$.$NFs9T$r<B9T$9$k$@$1$G!"(BDVI$B%U%!%$%k$r:n@.$9$k(B
$B$3$H$,$G$-$^$9!#(B

    platex Xins.ins
    sh mkpldoc.sh

$B$J$*!"(B pLaTeX2e $B$NJ8=q%U%!%$%k(B pldoc.tex $B$+$i(B pldoc.dvi $B$r:n@.$9$k$H$-!":w(B
$B0z$N@8@.$K(B mendex $B%W%m%0%i%`$rMQ$$$^$9!#$3$N$H$-!"(Bmendex 2.3g $B0J30$G$O!":w(B
$B0z%U%!%$%k$N@8@.;~$K%(%i!<$H$J$j$^$9$N$GCm0U$7$F$/$@$5$$!#(B

---------------------------------------------------------------------------
$B!|(B $B$=$NB>(B
---------------------------------------------------------------------------
pLaTeX2e $B$G3HD%$5$l$?5!G=$K$D$$$F$O(B platex.dtx $B$r;2>H$7$F$/$@$5$$!#(B
LaTeX2e $B$G3HD%$5$l$?5!G=$K$D$$$F$O(B LaTeX2e $B$N(B usrguid.tex $B$r;2>H$7$F$/$@$5$$!#(B
$BA02s$NHG$+$i$N=$@5$O!"(Bplnews*.tex $B$d(B ltnews*.tex $B$r;2>H$7$F$/$@$5$$!#(B

pTeX $B$H(B pLaTeX2e $B$N:G?7>pJs$O!"(B
    pTeX $B%[!<%`%Z!<%8!J(Bhttp://www.ascii.co.jp/pb/ptex$B!K(B
$B$h$j8x3+$7$F$$$^$9!#(B

$B$*Ld$$9g$o$;$d%P%0%l%]!<%H$J$I$O!"EE;R%a!<%k$G(B www-ptex@ascii.co.jp $B08$F(B
$B$K$*4j$$$7$^$9!#(B

---------------------------------------------------------------------------
$B3t<02q<R(B $B%"%9%-!<(B $B=PHG5;=QIt(B
$BCfLn(B $B8-(B   (ken-na@ascii.co.jp)
$BIY3_(B $B=(><(B (hideak-t@ascii.co.jp)
=== EOT ===================================================================
