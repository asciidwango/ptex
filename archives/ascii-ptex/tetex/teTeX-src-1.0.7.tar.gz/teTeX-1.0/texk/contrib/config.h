/* config.h: master configuration file, included first by all compilable
   source files (not headers).  */

#ifndef CONFIG_H
#define CONFIG_H

#ifdef WIN32
#  include <kpathsea/win32lib.h>
#endif

#endif /* CONFIG_H */
