/* pdftexextra.h: banner etc. for pdfTeX.

   This is included by pdfTeX, from ../etexextra.c
   (generated from ../lib/texmfmp.c).

Copyright (C) 1995, 96 Karl Berry.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

#define BANNER "This is pdfTeX, Version 3.14159-0.13d"
#define COPYRIGHT_HOLDER "Han The Thanh, Petr Sojka, and Jiri Zlatuska"
#define AUTHOR NULL
#define PROGRAM_HELP PDFTEXHELP
#define DUMP_VAR TEXformatdefault
#define DUMP_LENGTH_VAR formatdefaultlength
#define DUMP_OPTION "fmt"
#define DUMP_EXT ".fmt"
#define INPUT_FORMAT kpse_tex_format
#define INI_PROGRAM "pdfinitex"
#define VIR_PROGRAM "pdfvirtex"
