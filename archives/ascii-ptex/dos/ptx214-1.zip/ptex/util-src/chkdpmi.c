#include <stdio.h>
#include <dos.h>

int main()
{
  FILE *fp = stdout;
  union REGS r;

  r.x.ax = 0x1687;
  int86(0x2f,&r,&r);

  fputs("DPMI: ",fp);
  if (r.x.ax == 0)
    fprintf(fp,"version %u.%u\n",(unsigned int)r.h.dh,(unsigned int)r.h.dl);
  else fprintf(fp,"not available.\n");

  return 0;
}
