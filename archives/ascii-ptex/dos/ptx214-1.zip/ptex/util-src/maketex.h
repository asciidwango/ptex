#ifndef MAKETEX_H_INCLUDED
#define MAKETEX_H_INCLUDED

#ifndef MAXPATHLEN
#  define MAXPATHLEN 1024
#endif

extern void *xmalloc(unsigned int );
extern char *xstrdup(const char *);

extern int chdisk(int );

extern char *truncate_fontname(const char *);
extern int truncate_fontname_p(void);

extern int spawnvp_silently(char **argv);
extern int copy_file(const char *to,const char *from);
extern int mkdir_recursively(const char *dir);

#endif /* MAKETEX_H_INCLUDED */
