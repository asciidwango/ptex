#ifndef ALIAS_H_INCLUDED
#define ALIAS_H_INCLUDED

typedef struct alias_hash_item_s alias_hash_item;
struct alias_hash_item_s {
  char *key;
  char *value;
  alias_hash_item *next;
};

#define ALIAS_HASH_SIZE 67

typedef struct {
  alias_hash_item *hash_table[ALIAS_HASH_SIZE];
} AliasMap;

extern AliasMap *read_aliasmap();
extern char *refer_aliasmap();

#endif /* ALIAS_H_INCLUDED */
