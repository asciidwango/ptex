#define EXTERN extern
#include "../mfd.h"

#ifdef MSWINWIN
#include <stdlib.h>

/* Dummy functions. */

/* I hope someone implements these routines someday :-) */

static void mf_mswin_termscreen(void);

mf_mswin_initscreen()
{
  atexit(mf_mswin_termscreen);
  return 1;
}

mf_mswin_updatescreen()
{
}

mf_mswin_blankrectangle(left, right, top, bottom)
screencol left, right;
screenrow top, bottom;
{
}

mf_mswin_paintrow(row, init_color, tvect, vector_size)
screenrow row;
pixelcolor init_color;
transspec tvect;
register screencol vector_size;
{
}

static void
mf_mswin_termscreen(void)
{
}
#else
int mf_mswin_dummy;
#endif
