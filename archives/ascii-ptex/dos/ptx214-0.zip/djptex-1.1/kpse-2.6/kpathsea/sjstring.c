#ifdef SJIS_FN

#define SJSTRING_C
#include <stdio.h>
#include <ctype.h>
#include <kpathsea/c-proto.h>
#include <kpathsea/sjstring.h>

static int kanji_f;

char *sjstrchr P2C(char *,str,int, c)
{ unsigned char *s;
  s = (unsigned char *)str;
  kanji_f = 0;
  while (*s != '\0') {
    if (kanji_f) kanji_f = 0;
    else if (IS_KANJI1(*s)) kanji_f = 1;
    else if (*s == c) return (char *)s;
    s++;
  }
  return NULL;
}

char *sjstrrchr P2C(char *,str,int, c)
{
  char *last = NULL;
  char *x;
  while (*str != '\0') {
    str = sjstrchr(str,c);
    if (str == NULL) return last;
    last = str;
    str++;
  }
  return last;
}

char *sjstrlwr P1C(char *,str)
{
  unsigned char *s;
  s = (unsigned char *)str;
  kanji_f = 0;
  while (*s != '\0') {
    if (kanji_f) kanji_f = 0;
    else if (IS_KANJI1(*s)) kanji_f = 1;
    else *s = tolower(*s);
    s++;
  }
  return str;
}

char *sjstrupr P1C(char *,str)
{
  unsigned char *s;
  s = (unsigned char *)str;
  kanji_f = 0;
  while (*s != '\0') {
    if (kanji_f) kanji_f = 0;
    else if (IS_KANJI1(*s)) kanji_f = 1;
    else *s = toupper(*s);
    s++;
  }
  return str;
}

#else
int sj_string_dummy;
#endif
