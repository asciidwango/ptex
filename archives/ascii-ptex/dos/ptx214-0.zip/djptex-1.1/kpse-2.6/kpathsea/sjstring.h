#ifndef SJSTRING_H_INCLUDED
#define SJSTRING_H_INCLUDED

#define IS_KANJI1(c) \
	( ( (c) >= 0x81 && (c) <= 0x9f) || ( (c) >= 0xe0 && (c) <= 0xfc) )

#ifndef SJSTRING_C
extern char *sjstrchr P2H(const char *,int);
extern char *sjstrrchr P2H(const char *,int);
#endif
extern char *sjstrupr P1H(char *);
extern char *sjstrlwr P1H(char *);

#endif /* SJSTRING_H_INCLUDED */
