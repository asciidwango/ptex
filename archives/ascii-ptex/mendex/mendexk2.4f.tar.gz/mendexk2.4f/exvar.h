struct page {
	char *page;
	char *enc;
	char attr[3];
};

struct index {
	int num;
	char words;
	unsigned char *org[3];
	unsigned char *dic[3];
	unsigned char *idx[3];
	struct page *p;
	int lnum;
};

extern FILE *efp;

extern int lines,idxcount,acc;
extern int prange,fsti,lorder,bcomp,force,fpage,gflg,verb,debug;
extern int warn,scount,pattr[3];

extern struct index *ind;

extern char keyword[256];
extern char arg_open,arg_close;
extern char range_open,range_close;
extern char level,actual,encap,quote,escape;
extern char preamble[256],postamble[256];
extern char setpage_prefix[256],setpage_suffix[256];
extern char group_skip[256];
extern char lethead_prefix[256],lethead_suffix[256];
extern int lethead_flag;
extern char item_0[256],item_1[256],item_2[256];
extern char item_01[256],item_x1[256],item_12[256],item_x2[256];
extern char delim_0[256],delim_1[256],delim_2[256],delim_n[256],delim_r[256];
extern char encap_prefix[256],encap_infix[256],encap_suffix[256];
extern int line_max;
extern char indent_space[256];
extern int indent_length;
extern char symbol[256];
extern int symbol_flag;
extern int priority;
extern int letter_head;
extern unsigned char atama[256];
extern unsigned char page_compositor[256],page_precedence[256];
extern char character_order[256];
