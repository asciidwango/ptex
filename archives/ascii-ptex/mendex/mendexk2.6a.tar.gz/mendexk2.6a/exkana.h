extern unsigned char AKASATANA[];
extern unsigned char *akasatana;
extern unsigned char AIUEO[];
extern unsigned char *aiueo;

extern unsigned char ONBIKI[];
extern unsigned char ALPHAEND[];
extern unsigned char HIRATOP[];
extern unsigned char HIRAEND[];
extern unsigned char KATATOP[];
extern unsigned char KATAEND[];
