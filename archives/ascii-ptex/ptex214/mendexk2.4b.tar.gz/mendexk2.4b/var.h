struct page {
	char *page;
	char *enc;
	char attr[3];
};

struct index {
	int num;
	char words;
	unsigned char *org[3];
	unsigned char *dic[3];
	unsigned char *idx[3];
	struct page *p;
	int lnum;
};

FILE *efp;

int lines,idxcount,acc=0;
int prange=1,fsti=0,lorder=0,bcomp=0,force=0,fpage=0,gflg=0,verb=1,debug=0;
int warn=0,scount=0,pattr[3]={0,0,0};
static char roman[]={"ivxlcdm"},Roman[]={"IVXLCDM"};

struct index *ind;

char keyword[256]={"\\indexentry"};
char arg_open='{',arg_close='}';
char range_open='(',range_close=')';
char level='!',actual='@',encap='|',quote='\"',escape='\\';
char preamble[256]={"\\begin{theindex}\n"},postamble[256]={"\n\n\\end{theindex}\n"};
char setpage_prefix[256]={"\n  \\setcounter{page}{"},setpage_suffix[256]={"}\n"};
char group_skip[256]={"\n\n  \\indexspace\n"};
char lethead_prefix[256]={""},lethead_suffix[256]={""};
int lethead_flag=0;
char item_0[256]={"\n  \\item "},item_1[256]={"\n    \\subitem "},item_2[256]={"\n      \\subsubitem "};
char item_01[256]={"\n    \\subitem "},item_x1[256]={"\n    \\subitem "},item_12[256]={"\n      \\subsubitem "},item_x2[256]={"\n      \\subsubitem "};
char delim_0[256]={", "},delim_1[256]={", "},delim_2[256]={", "},delim_n[256]={", "},delim_r[256]={"--"};
char encap_prefix[256]={"\\"},encap_infix[256]={"{"},encap_suffix[256]={"}"};
int line_max=72;
char indent_space[256]={"\t\t"};
int indent_length=16;
int priority=0;
char symbol[256]={"Symbol"};
int symbol_flag=1;
int letter_head=1;
char atama[256]={akasatana};
char page_compositor[256]={"-"},page_precedence[256]={"rnaRA"};
char character_order[256]={"SEJ"};
