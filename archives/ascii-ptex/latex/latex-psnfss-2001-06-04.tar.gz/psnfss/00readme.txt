------------------------------------------------------------
         PSNFSS v8.2 -- installation instructions
------------------------------------------------------------
                                                  2001-06-04
                                              Walter Schmidt
                               

Contents
--------

- Overview
- Removing obsolete files
- Installing the virtual fonts, metrics and fd files
- Installing the PSNFSS macro packages
- Fonts required for PSNFSS
- Configuring dvips, pdfTeX etc.
- Extra packages required for PSNFSS
- Making sure that everything works
- Files from PSNFSS v7.x, which are no longer part of the
  distribution.


Overview
--------

PSNFSS, originally developed by Sebastian Rahtz, is a set of
LaTeX2e package files to load common PostScript text and
symbol fonts, together with packages for typesetting math
using virtual math fonts for Times and Palatino.

The collection is useless without the font description (fd)
files, virtual fonts (vf) and font metric (tfm) files for
the font families used by the packages.  On CTAN, those for
the Base 35 fonts are collected in the file lw35nfss.zip.
This archive also contains a font map file for dvips, and a
file named 8r.enc to reencode the Type1 fonts in a way that
is suitable for use with TeX.  Additionally, metrics, fd's
and font map files for the free typefaces Utopia, Charter
and Pazo are provided in the file freenfss.zip.

This document describes how to install PSBFSS 8.2.  The
details should be applicable to any TeX system with a
TDS-compliant directory layout.

*  Important changes and additions have been introduced with
*  this version; see the file changes.txt.
*
*  Notice that you _must_ re-install the .tfm, .vf and .fd
*  files from the archives lw35nfss.zip and freenfss.zip in 
*  order to make PSNFSS version 8.2 work properly! 
*  Several files have been updated; others have been added.

Detailed instructions how to _use_ PSNFSS with LaTeX can be
found in the PDF document psnfss2e.pdf.


Removing obsolete files
-----------------------

The "mathpazo" package was distributed and installed
separately so far; an improved version is now part of
PSNFSS.  The old version should have been installed in the
directory texmf/tex/latex/mathpazo, which is to be deleted.
The files reside in the directory texmf/tex/latex/psnfss
now.

The location of the related metrics and VFs is unchanged:
texmf/fonts/tfm/public/pazo and texmf/fonts/vf/public/pazo.

The following files of mathpazo 1.x are no longer needed:

  omlzplmj.fd
  zplmbj7m.tfm
  zplmrj7m.tfm
  zplmbj7m.vf
  zplmrj7m.vf


The remainder of this section is only relevant, if your
TeX system still includes version 7.x of PSNFSS:

The directory layout of your existent TeX system may differ
from PSNFSS 8.x, so you may have to delete certain files and
directories before installing this version; otherwise
obsolete files may not be overwritten in the next step.

* The font definition (.fd) files are kept in the directory
texmf/tex/latex/psnfss, as opposed to any sudirectories of
this).  Remove the following directories, if they exist on
your TeX system:

texmf/tex/latex/psnfss/bch
texmf/tex/latex/psnfss/pag
texmf/tex/latex/psnfss/pbk
texmf/tex/latex/psnfss/pcr
texmf/tex/latex/psnfss/phv
texmf/tex/latex/psnfss/pnc
texmf/tex/latex/psnfss/ppl
texmf/tex/latex/psnfss/psy
texmf/tex/latex/psnfss/ptm
texmf/tex/latex/psnfss/put
texmf/tex/latex/psnfss/pzc
texmf/tex/latex/psnfss/pzd
texmf/tex/latex/psnfss/pzc
texmf/tex/latex/psnfss/pzd

* There are no separate subdirectories for the "mathptm" and
"mathptmx" virtual math fonts; instead, these fonts are kept
together with the "Times" text fonts.  In case the following
directories exist on your TeX system, they are to be
removed:

texmf/fonts/tfm/adobe/mathptm
texmf/fonts/tfm/adobe/mathptmx
texmf/fonts/vf/adobe/mathptm
texmf/fonts/vf/adobe/mathptmx
texmf/tex/latex/mathptm
texmf/tex/latex/mathptmx

* The "mathpple" bundle was distributed and installed
separately so far; it is now part of PSNFSS.  In case it was
installed, the following directories must be removed now:

texmf/fonts/tfm/public/mathpple
texmf/fonts/vf/public/mathpple
texmf/tex/latex/mathpple
texmf/doc/latex/mathpple

* Make sure that there is only one instance of the file 
psyr.tfm (metrics for Adobe Symbol) in your TeX system; it 
must reside in the directory texmf/fonts/tfm/adobe/symbol.

* The file psyro.tfm resides in the directory
texmf/fonts/tfm/adobe/times now, since it is used in
conjunction with the virtual Times math fonts only.  Be sure
to delete any other instance of this file, which may reside,
e.g., in the directory texmf/fonts/tfm/adobe/symbol.


Installing the virtual fonts, metrics and fd files
--------------------------------------------------

Unzip lw35nfss.zip and freenfss.zip in the texmf root
directory (usually named texmf) of your TeX system; thus,
all files will be unpacked into the right directories.

Note that the archives lw35nfss.zip and freenfss.zip do
_not_ include the metrics of the "raw" (= not re-encoded)
PostScript text fonts.  Whether or not these metrics are
actually required, is system-dependent; besides, they are
not special for PSNFSS.


Installing the PSNFSS macro packages
------------------------------------

Put all the files from the CTAN directory
macros/latex/required/psnfss (except for the .zip archives)
into a directory where you keep documented LaTeX sources.
In a TDS compliant system this should be the directory

  texmf/source/latex/psnfss.

Run LaTeX on the installation script psfonts.ins; this will
create the packages.  

Move all the .sty files, which have been created, to a
directory where LaTeX will find them.  In a TDS compliant
system this should be the directory 

  texmf/tex/latex/psnfss.

The latter step is executed automagically by the
installation script, provided that your DocStrip program has
been configured appropriately and the target directory
exists already.

Move the documentation file psnfss2e.pdf to a suitable
directory; in a TDS compliant system this should be

  texmf/doc/latex/psnfss.

You may want to typeset the documentation of the package
code, too:  Run the file psfonts.dtx through LaTeX.


Fonts required for PSNFSS
-------------------------

The "Base 35" fonts
  Whether or not these fonts must be available to the dvi
  driver as "real" Type1 fonts, depends on the particular
  application (dvips, pdfTeX, VTeX etc.)  and whether the 
  fonts are to be embedded in the final PostScript or PDF
  documents.
  
Adobe Utopia
Bitstream Charter
  These Type1 fonts can be obtained for free from various
  sources.  Be sure to install the files with the names
  according to the KB scheme:
  
  Utopia-Regular          putr8a.pfb
  Utopia-Italic           putri8a.pfb
  Utopia-Bold             putb8a.pfb
  Utopia-BoldItalic       putbi8a.pfb
  CharterBT-Roman         bchr8a.pfb
  CharterBT-Italic        bchri8a.pfb
  CharterBT-Bold          bchb8a.pfb
  CharterBT-BoldItalic    bchbi8a.pfb
  
Pazo
  These Type1 fonts can be obtained from the CTAN directory
  fonts/mathpazo.
  
  PazoMath-Bold           fplmb.pfb
  PazoMathBlackboardBold  fplmbb.pfb
  PazoMath-BoldItalic     fplmbi.pfb
  PazoMath                fplmr.pfb
  PazoMath-Italic         fplmri.pfb

Computer Modern
RSFS (Ralph Smith's Formal Script)
Euler Math
  These font families are required when typesetting math
  using the packages mathptm, mathptmx, mathpple, or
  mathpazo.
  
  They are available in Type1 as well as METAFONT format; it
  is recommended to provide the Type1 variants, if you want
  to create PostScript or PDF documents.  The particular
  fonts eurm10 (Euler Roman 10pt) and eurb10 (Euler Roman
  Bold 10pt) are special:  They _must_ be provided in Type1
  format so that obliqued versions, named eurmo10 and
  eurbo10, can be generated from them.


Configuring dvips and pdfTeX
----------------------------

The distribution includes the following fonts map files for
use with dvips, which are unpacked to the directory
dvips/psnfss:

psnfss.map:     for the Base35 fontsm, eurmo10 and eurbo10
charter.map:    for Bitstream Charter
utopia.map:     for Adobe Utopia
pazo.map        for the Pazo math fonts

The map files don't include any entries for the "raw" (= not
re-encoded) PostScript text fonts, because these are usually
not required for use with dvips.

charter.map, utopia.map and pazo.map are equally suitable
for use with pdfTeX.  

As to psnfss.map, it needs to be modified for use with
pdfTeX, with respect to the fonts that must be embedded into
PDF files.

Except for the addition of pazo.map, there is no change over
the map files of version 8.1!


Extra packages required for PSNFSS
----------------------------------

The "Graphics" bundle must be installed, since PSNFSS will
make use of the package keyval.sty.


Making sure that everything works
---------------------------------

Run the test following files through LaTeX:

  test0.tex
  test1.tex
  test2.tex
  test3.tex
  mathtest.tex 
  pitest.tex


Files from PSNFSS v7.x, which are no longer part of the
distribution.
-------------------------------------------------------

The files for the commercial Lucida Bright and MathTime
fonts are distributed from the CTAN directory
macros/latex/contrib/supported/psnfssx/ now.

-- finis
