#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *vfp;
char *atfmname,*vtfmname,*afmname,*vfname;

FILE *vfopen();

main(argc,argv)
int argc;
char **argv;
{
	int i,j;
	FILE *afp;

	if (argc != 3) {
		fprintf(stderr,"MAKEJVF ver.1.0 -- make Japanese VF file.\n");
		fprintf(stderr,"%% makejvf <TFMfile> <PSfontTFM>\n");
		exit(0);
	}

	atfmname = strdup(argv[1]);

	vfname = strdup(argv[1]);
	for (i = strlen(vfname)-1 ; i >= 0 ; i--) {
		if (vfname[i] == '/') {
			vfname = &vfname[i+1];
			break;
		}
	}
	if (!strcmp(&vfname[strlen(vfname)-4],".tfm")) {
		vfname[strlen(vfname)-4] = '\0';
	}
	strcat(vfname,".vf");

	vtfmname = strdup(argv[2]);
	if (!strcmp(&vtfmname[strlen(vtfmname)-4],".tfm")) {
		vtfmname[strlen(vtfmname)-4] = '\0';
	}

	tfmget(atfmname);

	maketfm(vtfmname);

	vfp = vfopen(vfname);

	for (i=0;i<94;i++)
		for (j=0;j<94;j++)
			writevf((0x21+i)*256+(0x21+j),vfp);

	vfclose(vfp);

	exit(0);
}
