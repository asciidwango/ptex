char *kpathsea_version_string = (char *) "kpathsea version 3.0";

/* If you are redistributing a modified version of my original
   distribution, please change this address.

   Also change the address in makempx.in, mpto.c, and newer.c in
   web2c/mpware/, and in dvilj/dvihp.

   Thanks.  --kb@cs.umb.edu  */

char *kpse_bug_address = (char *) 
  "Email bug reports to tex-k@mail.tug.org.\n";
