/* paths.h: Generated from texmf.cnf Tue Feb 11 15:27:54 JST 1997.  */
#ifndef DEFAULT_TEXMF
#define DEFAULT_TEXMF "/usr/local/share/texmf"
#endif
#ifndef DEFAULT_TEXMFMAIN
#define DEFAULT_TEXMFMAIN "/usr/local/share/texmf"
#endif
#ifndef DEFAULT_TEXMFDBS
#define DEFAULT_TEXMFDBS "/usr/local/share/texmf"
#endif
#ifndef DEFAULT_TEXINPUTS
#define DEFAULT_TEXINPUTS ".;/usr/local/share/texmf/tex//"
#endif
#ifndef DEFAULT_TEXINPUTS
#define DEFAULT_TEXINPUTS ".;/usr/local/share/texmf/tex//"
#endif
#ifndef DEFAULT_MFINPUTS
#define DEFAULT_MFINPUTS ".;/usr/local/share/texmf/metafont//;{/usr/local/share/texmf/fonts,/var/tex/fonts}//source//"
#endif
#ifndef DEFAULT_MPINPUTS
#define DEFAULT_MPINPUTS ".;/usr/local/share/texmf/metapost//"
#endif
#ifndef DEFAULT_TEXFORMATS
#define DEFAULT_TEXFORMATS ".;/usr/local/share/texmf/web2c"
#endif
#ifndef DEFAULT_MFBASES
#define DEFAULT_MFBASES ".;/usr/local/share/texmf/web2c"
#endif
#ifndef DEFAULT_MPMEMS
#define DEFAULT_MPMEMS ".;/usr/local/share/texmf/web2c"
#endif
#ifndef DEFAULT_TEXPOOL
#define DEFAULT_TEXPOOL ".;/usr/local/share/texmf/web2c"
#endif
#ifndef DEFAULT_MFPOOL
#define DEFAULT_MFPOOL ".;/usr/local/share/texmf/web2c"
#endif
#ifndef DEFAULT_MPPOOL
#define DEFAULT_MPPOOL ".;/usr/local/share/texmf/web2c"
#endif
#ifndef DEFAULT_VARTEXFONTS
#define DEFAULT_VARTEXFONTS "/var/tex/fonts"
#endif
#ifndef DEFAULT_VFFONTS
#define DEFAULT_VFFONTS ".;/usr/local/share/texmf/fonts//vf//"
#endif
#ifndef DEFAULT_TFMFONTS
#define DEFAULT_TFMFONTS ".;{/usr/local/share/texmf/fonts,/var/tex/fonts}//tfm//"
#endif
#ifndef DEFAULT_PKFONTS
#define DEFAULT_PKFONTS ".;{/usr/local/share/texmf/fonts,/var/tex/fonts}//pk/$MAKETEX_MODE//"
#endif
#ifndef DEFAULT_GFFONTS
#define DEFAULT_GFFONTS ".;/usr/local/share/texmf/fonts//gf/$MAKETEX_MODE//"
#endif
#ifndef DEFAULT_GLYPHFONTS
#define DEFAULT_GLYPHFONTS ".;/usr/local/share/texmf/fonts"
#endif
#ifndef DEFAULT_TEXFONTMAPS
#define DEFAULT_TEXFONTMAPS ".;/usr/local/share/texmf/fontname"
#endif
#ifndef DEFAULT_BIBINPUTS
#define DEFAULT_BIBINPUTS ".;/usr/local/share/texmf/bibtex/bib//"
#endif
#ifndef DEFAULT_BSTINPUTS
#define DEFAULT_BSTINPUTS ".;/usr/local/share/texmf/bibtex/bst//"
#endif
#ifndef DEFAULT_MFTINPUTS
#define DEFAULT_MFTINPUTS ".;/usr/local/share/texmf/mft//"
#endif
#ifndef DEFAULT_TEXPSHEADERS
#define DEFAULT_TEXPSHEADERS ".;/usr/local/share/texmf/dvips//;/usr/local/share/texmf/fonts//type1//"
#endif
#ifndef DEFAULT_T1FONTS
#define DEFAULT_T1FONTS ".;/usr/local/share/texmf/fonts//type1//"
#endif
#ifndef DEFAULT_AFMFONTS
#define DEFAULT_AFMFONTS ".;/usr/local/share/texmf/fonts//afm//"
#endif
#ifndef DEFAULT_TEXCONFIG
#define DEFAULT_TEXCONFIG ".;/usr/local/share/texmf/dvips//"
#endif
#ifndef DEFAULT_INDEXSTYLE
#define DEFAULT_INDEXSTYLE ".;/usr/local/share/texmf/makeindex//"
#endif
#ifndef DEFAULT_TRFONTS
#define DEFAULT_TRFONTS "/usr/lib/font/devpost"
#endif
#ifndef DEFAULT_MPSUPPORT
#define DEFAULT_MPSUPPORT ".;/usr/local/share/texmf/metapost/support"
#endif
#ifndef DEFAULT_MIMELIBDIR
#define DEFAULT_MIMELIBDIR "/usr/local/etc"
#endif
#ifndef DEFAULT_MAILCAPLIBDIR
#define DEFAULT_MAILCAPLIBDIR "/usr/local/etc"
#endif
#ifndef DEFAULT_TEXDOCS
#define DEFAULT_TEXDOCS ".;/usr/local/share/texmf/doc//"
#endif
#ifndef DEFAULT_TEXSOURCES
#define DEFAULT_TEXSOURCES ".;/usr/local/share/texmf/source//"
#endif
#ifndef DEFAULT_OFMFONTS
#define DEFAULT_OFMFONTS ".;{/usr/local/share/texmf/fonts,/var/tex/fonts}//ofm//"
#endif
#ifndef DEFAULT_OPLFONTS
#define DEFAULT_OPLFONTS ".;{/usr/local/share/texmf/fonts,/var/tex/fonts}//opl//"
#endif
#ifndef DEFAULT_OVFFONTS
#define DEFAULT_OVFFONTS ".;{/usr/local/share/texmf/fonts,/var/tex/fonts}//ovf//"
#endif
#ifndef DEFAULT_OVPFONTS
#define DEFAULT_OVPFONTS ".;{/usr/local/share/texmf/fonts,/var/tex/fonts}//ovp//"
#endif
#ifndef DEFAULT_OTPINPUTS
#define DEFAULT_OTPINPUTS ".;/usr/local/share/texmf/omega/otp//"
#endif
#ifndef DEFAULT_OCPINPUTS
#define DEFAULT_OCPINPUTS ".;/usr/local/share/texmf/omega/ocp//"
#endif
#ifndef DEFAULT_KPSE_DOT
#define DEFAULT_KPSE_DOT "."
#endif
#ifndef DEFAULT_TEXMFCNF
#define DEFAULT_TEXMFCNF ".;$SELFAUTOLOC;$SELFAUTODIR;$SELFAUTODIR/share/texmf/web2c;$SELFAUTOPARENT;$SELFAUTOPARENT/share/texmf/web2c;/.$TETEXDIR;/./usr/local/share/texmf/web2c;$web2cdir"
#endif
#ifndef DEFAULT_MISSFONT_LOG
#define DEFAULT_MISSFONT_LOG "missfont.log"
#endif
#ifndef DEFAULT_TEX_HUSH
#define DEFAULT_TEX_HUSH "0"
#endif
#ifndef DEFAULT_MPXCOMMAND
#define DEFAULT_MPXCOMMAND "makempx"
#endif
