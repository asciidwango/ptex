#if 0
#include "kpse-api.h"

LONG ExpFltr(LPEXCEPTION_RECORD lpER)
{
  char tmp[16];
  sprintf(tmp, "%x %d", lpER->ExceptionCode, lpER->NumberParameters);
//  MessageBox(0, (char *)lpER->ExceptionInformation[0], tmp, 0);
  return EXCEPTION_EXECUTE_HANDLER;
}

static LONG __stdcall callback(UINT msg, DWORD p1, DWORD p2, DWORD p3)
{
  switch (msg) {
  case KPSE_CONSOLE_WRITE:
    fwrite((char *)p1, p2, 1, stdout);
    break;
  case KPSE_CONSOLE_FLUSH:
    fflush(stdout);
    break;
  default:
    return 0;
  }
  return 1;
}

DWORD WINAPI ChildThread(LPVOID lpvThreadParam)
{
	kpse_set_progname("test");
	printf("%s\n", kpse_var_expand("$VFFONTS"));
	printf("%s\n", kpse_path_search(kpse_var_expand("$VFFONTS"),"cunb.vf",FALSE));
	printf("%s\n", kpse_find_file("cunb.vg", kpse_tex_format, FALSE));
/*	LPVOID old_context = kpse_set_context(lpvThreadParam);
	kpse_free_context(old_context);
*/	fprintf(stderr, "thread start.\n");
	fflush(stderr);
/*	fprintf(stderr, program_invocation_name);
*/	getch();
}

int WINAPI WinMain(HINSTANCE hinstExe, HINSTANCE hinstPrec,
					LPSTR lpszCmdLine, int nCmdShow)
{
	DWORD dwThreadID;
	unsigned long h;
#if 0
	LPVOID context = kpse_get_context();
	kpse_set_callback(callback, 0);
#endif
	kpse_set_progname("test");
while(1) {
	h = _beginthreadex(NULL, 0, ChildThread, /*context*/0, 0, &dwThreadID);
	WaitForSingleObject(h, INFINITE);
}
/*	__try {
	kpse_open_file("abcdefg", kpse_gf_format);
	xfopen("abcedfg", "r");
	}
	__except (ExpFltr((GetExceptionInformation())->ExceptionRecord)) {
	}
*/}
#else
/* Compile: cl -MT test.c kpathsea.lib */

#include "kpse-api.h"

DWORD WINAPI thread_func(LPVOID *ptr)
{
  struct tbl {
    char *name;
    kpse_file_format_type fmt;
  };
  struct tbl files[] = {
    { "plain.tex", kpse_tex_format, },
    { "latex.ltx", kpse_tex_format, },
    { "platex.ltx", kpse_tex_format, },
    { "kinsoku.tex", kpse_tex_format, },
    { "classes.dtx", kpse_tex_format, },
    { "jclasses.dtx", kpse_tex_format, },
    { "not existing", kpse_tex_format, },
    { "texinfo.tex", kpse_tex_format, },
    { "cmr10.tfm", kpse_tfm_format, },
    { "cmex10.tfm", kpse_tfm_format, },
  };
  char *vars[] = {
    "TEXINPUTS",
    "MFINPUTS",
  };
  int i;
  kpse_set_progname("test");
  puts(basename("a:/ptex/texmf/web2c"));
  puts(basename("a:/�\texmf"));
  puts(basename("�\"));
  puts(basename("abc.def"));
  for (i=0;i<sizeof(files)/sizeof(struct tbl);i++) {
    char *p = kpse_find_file(files[i].name, files[i].fmt, 0);
    if (p) puts(p);
    else {
      puts(files[i].name);
      puts("Not found");
    }
  }

/*  for (i=0;i<sizeof(vars)/sizeof(char*);i++) {
    char *p = kpse_var_value(vars[i]);
    puts(vars[i]);
    puts(p ? p : "Not Found");
  }
*/
  _endthreadex(0);
}

void main()
{
  int i;
  for (i=0;i<10;i++) {
    DWORD idThread;
    HANDLE hThread;
    puts("Press any key to start thread");
    getc(stdin);
    hThread = (HANDLE)_beginthreadex(NULL, 0, thread_func, 0, 0, &idThread);
    if (hThread) {
      WaitForSingleObject(hThread, INFINITE);
      CloseHandle(hThread);
    }
  }
  puts("Press any key to terminate process");
  getc(stdin);
}
#endif
