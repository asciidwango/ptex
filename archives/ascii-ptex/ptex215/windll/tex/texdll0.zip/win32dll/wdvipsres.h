//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wdvips.rc
//
#define IDD_PROGRESS                    101
#define IDI_WDVIPS                      102
#define IDD_MESSAGE                     103
#define IDD_PRINT                       105
#define IDC_FILENAME                    1000
#define IDC_MESSAGE                     1001
#define IDC_PAGE                        1002
#define std32                           0x045f
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
