extern unsigned char poolfilecontents[];

static integer poolfilecontentsptr;

boolean openpoolfilecontents()
{
  poolfilecontentsptr = 0;
  return 1;
}

integer readpoolfilecontents()
{
  return poolfilecontents[poolfilecontentsptr] ?
    poolfilecontents[poolfilecontentsptr++] : EOF;
}

void readlnpoolfilecontents()
{
  while (poolfilecontents[poolfilecontentsptr]) {
    poolfilecontentsptr++;
    if (poolfilecontents[poolfilecontentsptr-1] == '\\n')
      break;
  }
}

boolean poolfilecontentseof()
{
  return poolfilecontents[poolfilecontentsptr] == 0;
}

boolean poolfilecontentseol()
{
  return poolfilecontents[poolfilecontentsptr] == '\n' ||
    poolfilecontentseof();
}
