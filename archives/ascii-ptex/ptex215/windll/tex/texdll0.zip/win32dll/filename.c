#include <win32dll/win32lib.h>
#include <mbstring.h>

LPTSTR win32_unix2dos(LPTSTR path)
{
  LPTSTR p = path;
  while (p = _mbschr(p, '/'))
    *p++ = '\\';
  return path;
}

LPTSTR win32_dos2unix(LPTSTR path)
{
  LPTSTR p = path;
  while (p = _mbschr(p, '\\'))
    *p++ = '/';
  return path;
}

LPTSTR win32_concat_filename(LPCTSTR dir, LPCTSTR base)
{
  LPCTSTR p = _mbsrchr(dir, '\\');
  LPCTSTR q = _mbsrchr(dir, '/');
  LPTSTR s, r;
  if (p < q) p = q;
  if (p == dir+strlen(dir)-1 ||
      (!p && isalpha(dir[0]) && dir[1] == ':' && dir[2] == 0))
    s = win32_concat(dir, base);
  else
    s = win32_concat3(dir, "\\", base);
  
  return win32_unix2dos(s);
}
