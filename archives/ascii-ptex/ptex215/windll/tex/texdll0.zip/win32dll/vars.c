#include <win32dll/win32lib.h>

Win32Context* win32_dll_context = NULL;
