#include "win32lib.h"
#include "maketexlib.h"

/* sorry. not implemented yet. */

BOOL WINAPI MakeTeXMFMain(LPSTR lpszFileName, DWORD dwLen, LPCSTR lpszFontName)
{
  return FALSE;
}
