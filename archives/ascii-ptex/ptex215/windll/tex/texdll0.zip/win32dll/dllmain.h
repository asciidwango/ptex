#ifndef dllmain_h_included
#define dllmain_h_included

#define TeXDLL_IMPLEMENTATION_CODE
#include <win32dll/texdll.h>
#undef boolean

typedef struct {
  LONG  exit_code;
  LPTSTR jobname;
  LPTSTR output_filename;
  LPTSTR output_basename;
  LPTSTR tfm_filename;
  LPTSTR log_filename;
  LPTSTR error_filename;
  DWORD error_line;
  
  /* Internal purposes. */
  HWND hMsgWnd;
  HANDLE hBgThread;
  DWORD idBgThread;
  HINSTANCE hInstance;
  HANDLE hBgDoneEvent;
  
  Win32Context* pWin32Context;
} TeXContext;

typedef TeXContext* LPTeXContext;

#endif /* dllmain_h_included */
