#include <setjmp.h>

int main(int argc, char**argv)
{
  volatile int exit_code;
  extern jmp_buf win32_exit_jmp;
  
  if ((exit_code = setjmp(win32_exit_jmp)) != 0) {
    return exit_code;
  }
  win32_init_module(GetModuleHandle(NULL));
  win32_init_cui_callback();
  if (!win32_init_main(win32_standard_cui_callback, NULL, NULL))
    return 1;
  exit_code = main_sub(argc, argv);
  win32_uninit_main();
  return exit_code;
}

#define main main_sub
