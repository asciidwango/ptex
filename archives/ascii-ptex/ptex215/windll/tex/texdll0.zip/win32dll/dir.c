#include <win32dll/win32lib.h>
#include <mbstring.h>

BOOL win32_mkdir_recursively(LPCSTR dirName)
{
  char buf[2000];
  LPCSTR p = dirName;
  LPSTR q = buf;
  while (*p) {
    LPCSTR r = _mbschr(p, '\\');
    if (!r) r = p + strlen(p);
    while (p < r) {
      *q++ = *p++;
    }
    if (q == buf+2 && q[-1] == ':')
      ;
    else {
      WIN32_FIND_DATA findData;
      HANDLE hFind;
      *q = '\0';
      hFind = FindFirstFile(buf, &findData);
      if (hFind == INVALID_HANDLE_VALUE)  {
	if (!CreateDirectory(buf, NULL))
	  return FALSE;
      }
      else
	FindClose(hFind);
    }
    while (*p && *p == '\\')
      p++;
    *q++ = '\\';
  }
  return TRUE;
}
