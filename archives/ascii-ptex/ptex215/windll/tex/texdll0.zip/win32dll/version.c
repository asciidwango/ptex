#include <win32dll/win32lib.h>

char* win32_versionstring = " (Web2c 7.0, Win32 DLL 1.0.2)";
char* win32_bug_address = "Email bug report about DLL to asayama@vsp.cpg.sony.co.jp or TPM03937@pcvan.or.jp";
