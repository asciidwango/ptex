This is my minimal tex&mf lib distribution.
It provides only enough to build the format files.

Files which are installed by other distributions (e.g., the LaserJet
fonts by dviljk) are omitted.

For a description of the default directory layout, see the file
kpathsea/HIER in any of my source distributions.  It follows the TeX
Directory Structure (http://www.tug.org/tds).

Additional TeX-related stuff of all kinds is on the Comprehensive TeX
Archive Network sites in the directory /tex-archive:
   ftp.tex.ac.uk
   ftp.dante.de
*and* their mirrors, such as ftp://ftp.cdrom.com/pub/tex/ctan (finger
ctan@ftp.tug.org, or retrieve README.mirrors from one of the primary sites).

In particular, you will almost certainly want additional core LateX
packages, such as babel (unless you only want to typeset English) and
graphics; most likely additional fonts, PostScript and otherwise;
perhaps amstex and amslatex; etc.

To suggest additional files for this distribution, email me.

--kb@mail.tug.org
