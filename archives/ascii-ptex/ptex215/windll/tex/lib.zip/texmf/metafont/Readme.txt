Following from ftp://labrea.stanford.edu/pub/tex/local/lib:
black.mf blackaps.mf blackimagen.mf blacklino.mf gray.mf grayaps.mf
grayimagen.mf grayimagen3.mf logod10.mf logosl9.mf oneone.mf random.mf
slantaps4.mf slantlino4.mf

modes.mf from ftp://ftp.tug.org/tex/modes.mf.

All others from .../lib on labrea.

logo* moved to fonts/public/logo/src.
manfnt.mf and mfman.mf moved to .../manual.
