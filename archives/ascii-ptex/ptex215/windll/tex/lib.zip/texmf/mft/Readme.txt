e.mft from local/lib.
All others from lib.
