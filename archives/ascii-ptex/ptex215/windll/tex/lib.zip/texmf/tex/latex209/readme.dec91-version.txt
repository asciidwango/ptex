LaTeX version 2.09 -- Release of Dec 1, 1991
--------------------------------------------

This release supercedes ILaTeX which is to disappear.

There are some incompatibilities due to bug fixes. For more
information see latex.bug. Especially fix #197 (changing the counter
in thebibliography) and style changes #56/57 might cause problems for
styles that were derived from the article standard document style.

The Metafont source files have also been updated. This does not mean
that the shape of the characters were changed, only a few internals
like the font identifier for the invisible fonts, and the addition of
a check so that the line and circle fonts can no longer be run with
cmbase.

It should be noted explicitly that ALL files have to be updated:
otherwise it will not work.
