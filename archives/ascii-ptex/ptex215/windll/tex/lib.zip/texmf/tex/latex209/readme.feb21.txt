The letter document style dated 5-Nov-91, contained in the Jan92
release of LaTeX has a severe problem: the spacing of the list
environment and friends will come out wrong. The same problem appears
in all document styles and style options that redefine the
\begin{document} command. It is necessary to add the control sequence

   \@noskipsecfalse

to the end of the definition of the \document macro.

I append a diff to this message, so that you can update letter.doc,
letter.sty, and latex.bug.

The updated files will be available in the archives during next week.

   Rainer Schoepf
   Konrad-Zuse-Zentrum                       ,,Ich mag es nicht, wenn
    fuer Informationstechnik Berlin            sich die Dinge so frueh
   Heilbronner Strasse 10                      am Morgen schon so
   D-1000 Berlin 31                            dynamisch entwickeln!''
   Federal Republic of Germany
   <Schoepf@sc.ZIB-Berlin.de> or <Schoepf@sc.ZIB-Berlin.dbp.de>

----------------------------------------------------------------
