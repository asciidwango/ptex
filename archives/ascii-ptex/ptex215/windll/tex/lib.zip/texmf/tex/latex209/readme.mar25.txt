LaTeX updates, as of March 25, 1992.

Since plain.tex was changed by Donald Knuth recently, it seems
worthwhile to make the same changes to the lplain.tex and splain.tex
files. At the same time, a number of minor problems and oversights
have been corrected. For a detailed list consult the file latex.bug.


The following files have been changed:


latex.bug
latex.tex
local.tex
lplain.tex
slitex.tex
splain.tex
lcircle10.mf
lcirclew10.mf
line.mf
line10.mf
linew10.mf
letter.doc
proc.doc
bezier.sty
letter.sty
proc.sty


Note: the changes to the Metafont files do not affect the fonts
themselves, they provide better error checking when Metafont is used
with the wrong base file. Therefore it is NOT necessary to recompile
the fonts.

