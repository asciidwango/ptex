The file aexam.sty is an AMS-TeX style file for typesetting examinations.
Some features are:

 o   Simple input format (requires only very basic knowledge of TeX)
 o   Automatic numbering of problems
 o   Automatic lettering of multiple choice items
 o   Automatic count of the number of problems and pages
 o   Automatic production of answer keys for multiple choice exams
 o   Flexible problem spacing
 o   Choice of several built in topmatter formats, as well as user-defined
 o   Highly customizable with reasonable defaults for all items
 o   Fully documented with user's guide and sample exams

The contents of the AEXAM distribution are:

README       - this file
aexam.sty    - the style file, to be in some directory on your TeX input path
aexamdoc.tex - AMS-TeX source for the user's guide
sample1.tex  - multiple choice exam illustrating basic usage of aexma.sty
sample2.tex  - exam illustrating some of the advance features

These files may be distributed without restriction.

I would appreciate hearing of problems or sugggestions for improvements.
Additional topmatter styles are also welcome.
--
Douglas N. Arnold                                    dna@math.psu.edu
Dept. of Mathematics, Penn State University
