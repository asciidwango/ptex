LaTeX version 2.09 -- Release of Jan 14, 1992
---------------------------------------------

After the release of Dec91 a number of errors and incompatibilities
were reported. In particular, the titlepage option of the article
document style did no longer work, and there were two problems with
the thebibliography environment:

- Documents with more than 26 entries would produce strange error messages.
- Styles derived from article would produce wrong numbers.

These errors (and a few minor ones) have been corrected.

The files changed are (see also LATEX.BUG for more details):

latex.tex
local.tex
lplain.tex
slitex.tex
splain.tex
article.doc/sty
art10.doc/sty
art11.doc/sty
art12.doc/sty
book.doc/sty
bk10.doc/sty
bk11.doc/sty
bk12.doc/sty
openbib.doc/sty
report.doc/sty
rep10.doc/sty
rep11.doc/sty
rep12.doc/sty
latex.bug

