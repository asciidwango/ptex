This directory is for files that can work with more than one format --
plain, LaTeX, AMSTeX, etc.
