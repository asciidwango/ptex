Following from labrea.stanford.edu:~ftp/tex/local/lib.
All others from .../lib.

fontchart.tex
gkpmac.tex
list.tex
llist.tex
wlist.tex
picmac.tex
wlist.tex
letter.tex
