README                                                 11 January 1997

This is a documentation file to accompany the AMS-TeX 2.1 distribution.

AMS-TeX is a macro package that works with the TeX typesetting program.
In order to install AMS-TeX, you must already have a working TeX system.
TeX implementations are available for most computers, both commercial and
free or shareware implementations.  Information on sources of free TeX
software and vendors of commercial implementations can be found in the
TeX Resources area of the AMS home pages on the World Wide Web, at
  http://www.ams.org/tex/


FILES IN THE AMS-TeX DISTRIBUTION

The following files in this directory should be copied into the
directory on your system where your implementation of TeX looks for
input files. 

 amsppt.sty    amsppt1.tex   amssym.tex    amstex.ini    amstex.tex

Copy the remaining files in this directory and its subdirectory (named
`doc') into a corresponding directory tree on your system. ALSO, retrieve
all of the .tfm files for AMSFonts 2.1 from the tfm-files subdirectory
of the amsfonts directory on this archive. (Note: set the file type to
binary in FTP when transferring .tfm files.) Even if you do not use
AMSFonts 2.1, you will need the .tfm files to use amsppt.sty and to
TeX the accompanying documentation for AMS-TeX.

The .tfm files from the tfm-files directory of the amsfonts subdirectory
on this archive should be copied into the directory on your system where
your implementation of TeX looks for .tfm files.

[As an alternative to copying the individual .tfm files, a tfm.tar file
(in the /pub/tex directory at e-math) contains all the .tfm files in
`tar' format, if your system has facilities for unpacking it.]

The `doc' subdirectory contains four files:

amstinst.tex -  Installation instructions, comprising Appendixes B, C & D
                of amsguide.tex. Process this file using Plain TeX to
                produce a printed copy of the installation instructions
                before AMS-TeX 2.1 is installed. It gives more details
                than the installation section below.
amsguide.tex -  The TeX input file for the AMS-TeX User's Guide.
                Once you have completed the installation of AMS-TeX 2.1,
                run this file through TeX using AMS-TeX 2.1. The output
                will be a guide to using AMS-TeX 2.1.
joyerr.tex  -   The TeX input file for a document listing errata to
                The Joy of TeX prior to AMS-TeX 2.0. It also should be
                run through TeX using AMS-TeX 2.1.
amsppt.doc  -   Technical documentation for amsppt.sty.


INSTALLING AMS-TeX 2.1 ON YOUR SYSTEM

As described above, copy amsppt.sty, amsppt1.tex, amssym.tex, amstex.ini,
and amstex.tex into the directory where your implementation of TeX looks
for input files, and copy all the .tfm files for AMSFonts 2.1 into the
directory where your implementation of TeX looks for .tfm files.

Then run amstex.ini through INITEX (the version of TeX which has no
format preloaded, distributed with your implementation of TeX). It will
produce a format file which will function as a preloaded version of
AMS-TeX. Place this format file in the directory where your implementation
of TeX  looks for format files, and you are ready to use AMS-TeX 2.1.

If you habitually use the AMSPPT documentstyle, you may prefer to
include it in the format file you create. This can be done by editing
the file amstex.ini, using any text editor, and uncommenting the line
that reads "\documentstyle{amsppt}".  Before creating the format file,
read Appendix D from the installation instructions.

We recommend that, as a first test of your installation, you run the
file amsguide.tex through TeX, and print out the output. This will
provide further information about using AMS-TeX.

========================================================================
Highlights of the differences between versions 2.0 and 2.1:

AMSTEX.TEX
----------
---Improvements to the mechanisms for loading various fonts in
the AMSFonts package. For example, \loadeusm now defines a
\eusm command that can be used like \roman or \bold.

---Revamped \printoptions command.

---Some internal cleanup to reduce memory usage in some of TeX's
memory categories (notably hash size).

---Informational messages appear on screen identifying the
modules within amstex.tex during the creation of a format file.

AMSPPT.STY
----------
(See the user's guide (amsguide.tex) and amsppt.doc, section 18,
for full details.)

---\curraddr was added, for giving the current address of an author,
if different from the address given in \address.

---\rom was added, for preventing unwanted italicization of certain
things, such as parentheses or numbers, in theorems and other italic
passages.  \rom automatically inserts italic corrections.

---The implementation of \nofrills was completely changed, to provide
better error messages for a missing or misspelled \endkeywords or
similar end command when reading a delimited argument.

---Multiple \thanks commands in the top matter will now produce
multiple acknowledgment footnotes instead of discarding all but the
last one.

---A period is no longer added automatically at the end of a
\thanks. (NOTE: THIS CHANGE IS NOT BACKWARD COMPATIBLE---DOCUMENT
FILES WILL HAVE TO BE MODIFIED.)

---\subjclass was updated to use the date (1991) of the current
Mathematics Subject Classification scheme. (NOTE: THIS CHANGE IS NOT
BACKWARD COMPATIBLE. DOCUMENT FILES NEED NOT BE MODIFIED BUT THE
OUTPUT WILL BE DIFFERENT.)

---\widestnumber\item now works as claimed in the User's Guide.

---The missing \par in the internal command \penaltyandskip@ was added.

---Additional checks were added for runaway \proclaim, \definition,
\ref, \roster, etc.  The internal macro \runaway@ was changed to make
its usage more consistent and robust; in the process its name was
changed to \add@missing (and as the name suggests, it now tries to
recover by adding the missing \end... command).

---As with amstex.tex, informational messages were added identifying the
modules within amsppt.sty.

---The bibliography macros were substantially modified to correct
another longstanding bug: line breaks after explicit hyphens,
mathbins, and mathrels were inhibited. This also involved changing the
\ref-specific version of \nofrills.  BACKWARD COMPATIBILITY (WITH
VERSION 2.0) IS NOT COMPLETE WITH RESPECT TO \nofrills IN THE
BIBLIOGRAPHY MACROS.  \nofrills NOW SHOULD ALWAYS FOLLOW IMMEDIATELY
AFTER THE NAME OF THE FIELD TO WHICH IT APPLIES, E.G., \transl\nofrills,
OR \paper\nofrills. This is more consistent with the usage of \nofrills
outside of the references section. \nofrills will cause all the "frills",
such as the parentheses around years in journal article citations, or
words like "eds." or "vol." that are supplied automatically, to be
omitted for the given field.  In addition, it will suppress the
automatic punctuation at the end of the field, if any.

---A \refstyle command was added to allow users to specify one of the
three different reference styles most commonly used in AMS publications:
letter labels in square brackets; unnumbered; and numbered (denoted A,
B, and C, respectively). The syntax is "\refstyle{A}" (immediately after
the \documentstyle command). Style C, numbered with arabic numerals, is
the default selected by amsppt.sty.  The \refstyle command ensures 
proper correspondence between the formatting of cites in the main text 
and the formatting of the references section. Also, \key can now be used
for all reference labels, and the \no command is redundant (though still
supported, for backward compatibility).

---\miscnote was added, and used in the implementation of \toappear,
so that \toappear and \finalinfo would not be mutually exclusive.
\miscnote might also be used for things like "preprint" or
"submitted".  Unlike \finalinfo, \miscnote automatically adds
parentheses.

---\procinfo was added, to give place and date where the meeting
took place, for a proceedings volume reference.

---\eds or \ed information will now be used in place of an author's
name, if \by is absent.  This would be for collections or proceedings
volumes that are cited as a whole, instead of citing a single paper
within the volume.

AMSTEX.INI
----------
File to make format file creation more convenient. See the
user's guide and/or installation notes above.

AMSPPT1.TEX
-----------
Compatibility file to allow processing of AMS-TeX 1.1 and earlier
documents under AMS-TeX 2.0+. See the user's guide.


(NOTE: The author packages available in the e-math directory
/pub/author-info/packages are compatible with the January 1997 version
of AMS-TeX 2.1.  If you have previously received an AMS-TeX author package
for use with an earlier version of AMS-TeX, you must retrieve an upgraded
copy from this e-math area.)

========================================================================

Questions or comments can be directed to:

Technical Support
Electronic Products and Services 
American Mathematical Society
201 Charles Street
P.O. Box 6248
Providence, RI 02940   USA
     (800) 321-4AMS (321-4267) ext. 4080
     (401) 455-4080
Internet:  tech-support@ams.org
