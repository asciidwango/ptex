This directory contains some supporting data files
for fontname translation.  See the Web2c and Kpathsea manuals.
