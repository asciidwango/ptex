/* This string is appended to all the banners and used in --version.  */
#ifndef VERSION_STRING
#define VERSION_STRING " (Web2c 7.0)"
#endif

char *versionstring = VERSION_STRING;
