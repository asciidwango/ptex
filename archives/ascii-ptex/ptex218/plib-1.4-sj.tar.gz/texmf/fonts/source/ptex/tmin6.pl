(COMMENT
 tmin10 Propaty List File (Tate kumi)
               by Hisato Hamano
                  hisato-h@ascii.co.jp
)
(COMMENT THIS IS A KANJI FORMAT FILE)
(DIRECTION TATE)
(FAMILY MINCHO)
(FACE F MRR)
(CODINGSCHEME JIS X0208)
(DESIGNSIZE R 6.0)
(COMMENT DESIGNSIZE IS IN POINTS)
(COMMENT OTHER SIZES ARE MULTIPLES OF DESIGNSIZE)
(CHECKSUM O 35147750366)
(SEVENBITSAFEFLAG TRUE)
(FONTDIMEN
   (SLANT R 0.0)
   (SPACE R 0.0)
   (STRETCH R 0.091641)
   (SHRINK R 0.0)
   (XHEIGHT R 0.916443)
   (QUAD R 0.962216)
   (EXTRASPACE R 0.229101)
   (EXTRASTRETCH R 0.183283)
   (EXTRASHRINK R 0.114551)
   )
(GLUEKERN
   (LABEL D 0)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.107391 R 0.0      R 0.107391)
   (GLUE D 5 R 0.0      R 0.0      R 0.0     )
   (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 1)
   (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 4 R 0.0      R 0.0      R 0.0     )
   (GLUE D 5 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 7 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 2)
   (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 4 R 0.0      R 0.0      R 0.0     )
   (GLUE D 5 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 7 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 3)
   (GLUE D 0 R 0.107391 R 0.0      R 0.107391)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.107391 R 0.0      R 0.107391)
   (GLUE D 5 R 0.0      R 0.0      R 0.0     )
   (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 4)
   (GLUE D 0 R 0.962216 R 0.0      R 0.481108)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.962216 R 0.0      R 0.481108)
   (GLUE D 5 R 0.0      R 0.0      R 0.0     )
   (GLUE D 6 R 0.962216 R 0.0      R 0.481108)
   (GLUE D 7 R 0.962216 R 0.0      R 0.481108)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 5)
   (GLUE D 0 R 0.0      R 0.0      R 0.0     )
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.0      R 0.0      R 0.0     )
   (GLUE D 4 R 0.0      R 0.0      R 0.0     )
   (GLUE D 5 R 0.0      R 0.0      R 0.0     )
   (GLUE D 6 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 6)
   (GLUE D 0 R 0.0      R 0.0      R 0.0     )
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.0      R 0.0      R 0.0     )
   (GLUE D 4 R 0.0      R 0.0      R 0.0     )
   (GLUE D 5 R 0.0      R 0.0      R 0.0     )
   (GLUE D 6 R 0.0      R 0.0      R 0.0     )
   (GLUE D 7 R 0.240554 R 0.0      R 0.240554)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 7)
   (GLUE D 0 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 1 R 0.240554 R 0.0      R 0.240554)
   (GLUE D 2 R 0.240554 R 0.0      R 0.240554)
   (GLUE D 3 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 4 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 5 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 6 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 7 R 0.0      R 0.183283 R 0.0     )
   (GLUE D 8 R 0.240554 R 0.0      R 0.240554)
   (STOP)
   (LABEL D 8)
   (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 4 R 0.0      R 0.0      R 0.0     )
   (GLUE D 5 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   )
(CHARSINTYPE D 1
   �C �D 
   )
(CHARSINTYPE D 2
   �A �B 
   )
(CHARSINTYPE D 3
   �R �S �T �U �V �X
   �� �� �� �� �� �� �� �� �� ��
   �@ �B �D �F �H �b �� �� �� �� �� �� 
   )
(CHARSINTYPE D 4
   �H �I 
   )
(CHARSINTYPE D 5
   �\ �c �d 
   )
(CHARSINTYPE D 6
   �e �g �i �k �m �o �q �s �u �w �y 
   )
(CHARSINTYPE D 7
   �E �] �a �b 
   )
(CHARSINTYPE D 8
   �f �h �j �l �n �p �r �t �v �x �z 
   )
(TYPE D 0
   (COMMENT						���ʂ̊���
      )
   (CHARWD R 0.962216)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	�C�D
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	�A�B
      (GLUE D 3 R 0.107391 R 0.0      R 0.107391)	������
      (GLUE D 5 R 0.0      R 0.0      R 0.0     )	�S�p��
      (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)	�J�b�R�J��
      (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)	���c�L��
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	�J�b�R��
      )
   )
(TYPE D 1
   (COMMENT					�C�D
      (CHARSINTYPE D 1
         �C �D 
         )
      )
   (CHARWD R 0.481108)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)	����
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	�C�D
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	�A�B
      (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)	���J�i
      (GLUE D 4 R 0.0      R 0.0      R 0.0     )	�H�I
      (GLUE D 5 R 0.481108 R 0.183283 R 0.481108)	�S�p��
      (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)	�J�b�R�J��
      (GLUE D 7 R 0.481108 R 0.183283 R 0.481108)	���c�L��
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	�J�b�R��
      )
   )
(TYPE D 2
   (COMMENT					�A�B
      (CHARSINTYPE D 2
         �A �B 
         )
      )
   (CHARWD R 0.481108)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)	����
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	�C�D
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	�A�B
      (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)	���J�i
      (GLUE D 4 R 0.0      R 0.0      R 0.0     )	�H�I
      (GLUE D 5 R 0.481108 R 0.183283 R 0.481108)	�S�p��
      (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)	�J�b�R�J��
      (GLUE D 7 R 0.481108 R 0.183283 R 0.481108)	���c�L��
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	�J�b�R��
      )
   )
(TYPE D 3
   (COMMENT						������
      (CHARSINTYPE D 3
         �R �S �T �U �V �X
         �� �� �� �� �� �� �� �� �� ��
         �@ �B �D �F �H �b �� �� �� �� �� �� 
         )
      )
   (CHARWD R 0.747434)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.107391 R 0.0      R 0.107391)	����
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	�C�D
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	�A�B
      (GLUE D 3 R 0.107391 R 0.0      R 0.107391)	������
      (GLUE D 5 R 0.0      R 0.0      R 0.0     )	�S�p��
      (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)	�J�b�R�J��
      (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)	���c�L��
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	�J�b�R��
      )
   )
(TYPE D 4
   (COMMENT						�I�H
      (CHARSINTYPE D 4
         �H �I 
         )
      )
   (CHARWD R 0.962216)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.962216 R 0.0      R 0.481108)	����
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	�C�D
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	�A�B
      (GLUE D 3 R 0.962216 R 0.0      R 0.481108)	������
      (GLUE D 5 R 0.0      R 0.0      R 0.0     )	�S�p��
      (GLUE D 6 R 0.962216 R 0.0      R 0.481108)	�J�b�R�J��
      (GLUE D 7 R 0.962216 R 0.0      R 0.481108)	���c�L��
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	�J�b�R��
      )
   )
(TYPE D 5
   (COMMENT						�S�p��
      (CHARSINTYPE D 5
         �\ �c �d 
         )
      )
   (CHARWD R 0.962216)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.0      R 0.0      R 0.0     )	����
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	�C�D
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	�A�B
      (GLUE D 3 R 0.0      R 0.0      R 0.0     )	������
      (GLUE D 4 R 0.0      R 0.0      R 0.0     )	�I�H
      (GLUE D 5 R 0.0      R 0.0      R 0.0     )	�S�p��
      (GLUE D 6 R 0.240554 R 0.183283 R 0.240554)	�J�b�R�J��
      (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)	���c�L��
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	�J�b�R��
      )
   )
(TYPE D 6
   (COMMENT					�J�b�R�J��
      (CHARSINTYPE D 6
         �e �g �i �k �m �o �q �s �u �w �y 
         )
      )
   (CHARWD R 0.481108)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.0      R 0.0      R 0.0     )	����
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	�C�D
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	�A�B
      (GLUE D 3 R 0.0      R 0.0      R 0.0     )	������
      (GLUE D 4 R 0.0      R 0.0      R 0.0     )	�I�H
      (GLUE D 5 R 0.0      R 0.0      R 0.0     )	�S�p��
      (GLUE D 6 R 0.0      R 0.0      R 0.0     )	�J�b�R�J��
      (GLUE D 7 R 0.240554 R 0.0      R 0.240554)	���c�L��
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	�J�b�R��
      )
   )
(TYPE D 7
   (COMMENT					���c�L��
      (CHARSINTYPE D 7
         �E �] �a �b 
         )
      )
   (CHARWD R 0.481108)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.240554 R 0.183283 R 0.240554)	����
      (GLUE D 1 R 0.240554 R 0.0      R 0.240554)	�C�D
      (GLUE D 2 R 0.240554 R 0.0      R 0.240554)	�A�B
      (GLUE D 3 R 0.240554 R 0.183283 R 0.240554)	���J�i
      (GLUE D 4 R 0.240554 R 0.183283 R 0.240554)	�H�I
      (GLUE D 5 R 0.240554 R 0.183283 R 0.240554)	�S�p��
      (GLUE D 6 R 0.240554 R 0.183283 R 0.240554)	�J�b�R�J��
      (GLUE D 7 R 0.0      R 0.183283 R 0.0     )	���c�L��
      (GLUE D 8 R 0.240554 R 0.0      R 0.240554)	�J�b�R��
      )
   )
(TYPE D 8
   (COMMENT					�J�b�R��
      (CHARSINTYPE D 8
         �f �h �j �l �n �p �r �t �v �x �z 
         )
      )
   (CHARWD R 0.481108)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)	����
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	�C�D
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	�A�B
      (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)	���J�i
      (GLUE D 4 R 0.0      R 0.0      R 0.0     )	�H�I
      (GLUE D 5 R 0.240554 R 0.183283 R 0.240554)	�S�p��
      (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)	�J�b�R�J��
      (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)	���c�L��
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	�J�b�R��
      )
   )
